
# Root 也无法逾越的锁：一次 ColorOS A/B 更新"幽灵锁死"的验尸报告、自动化救砖及对 Google 的血泪控诉

## 序言：当 root 不再是上帝 🤡

在 Android 世界，root 一直是权力的代名词。我们挂载、改写、穿透，以为可以践踏一切软件规则——直到你遇到一个连 dd 都撞得头破血流的块设备。😨
本文记录了一次匪夷所思的 OTA 后遗症：系统完全正常，旧插槽却永锁不可写，root 权限形同虚设。 我将从案发现场展开，深入 Google 引以为傲的 A/B 无缝更新机制，引用 Android 官方文档和 AOSP 源码中的白纸黑字作为铁证，解剖其最脆弱的软组织，并最终展示如何用几行脚本就把 Google 的"幽灵"按回坟墓。文末还会附赠一个 KernelSU 模块，让你的设备从此自动免疫此绝症。😋
但在你开骂之前，请先读完这一段关键声明：本文描述的所有故障，均发生在已经刷机、获取 root 权限的设备上，且目前已确认的案例仅限 OnePlus 机型或搭载 ColorOS 系统的设备。未刷机、未解锁 Bootloader 的普通用户暂未报告遭遇此问题。 如果你不属于上述情况，本文可能与你无关，但也欢迎你当乐子看——看看 Google 的代码在失去系统完整性保护后，能暴露出多么离谱的脆弱性。🤣
如果你想看一篇 「技术验尸 + 官方文档铁证 + 源码铁证 + 内核机制 + 对 Google 的疯狂拷打」五位一体的长篇檄文，你来对地方了。

## 第一章：Android 系统更新服务——那个你从未关心过的幽灵 👻

在拿起手术刀解剖故障之前，我们必须先认识一下那个藏在系统阴影里的主角——update_engine。本章所有引用的描述均来自 Android 开源项目（AOSP）官方文档及源码，绝无杜撰，文末附有完整引用源链接。

### 1.1 A/B 无缝更新：Google 的骄傲 😎

Android 7.0 引入了 A/B 分区机制（Seamless Updates）。Android 官方文档如此定义它的目标[1]：

&gt; "A/B 系统更新（也称为无缝更新）的目标是确保在无线下载 (OTA) 更新期间在磁盘上保留一个可正常启动和使用的系统。采用这种方式可以降低更新之后设备无法启动的可能性，这意味着用户需要将设备送到维修和保修中心进行更换和刷机的情况将会减少。"

"A/B 系统更新（也称为无缝更新）的目标是确保在无线下载 (OTA) 更新期间在磁盘上保留一个可正常启动和使用的系统。采用这种方式可以降低更新之后设备无法启动的可能性，这意味着用户需要将设备送到维修和保修中心进行更换和刷机的情况将会减少。"

这一机制将 boot、system、vendor 等关键分区双份部署，分别称为 slot A 和 slot B。其核心设计哲学是：系统从"当前"槽位运行，但在正常操作期间，运行中的系统不会访问未使用的槽位中的分区，从而将未使用的槽位保留为后备，防范更新出错[1]。整个过程对于用户几乎是透明的，并且保留回滚能力——文档明确承诺："如果 OTA 失败，设备会启动到 OTA 之前的磁盘分区，并且仍然可以使用"[1]。

这一机制背后的核心守护进程就是 update_engine。官方文档明确写道："A/B 系统更新使用称为 update_engine 的后台守护进程以及两组分区"[1]。它是所有 OTA 操作（无论增量还是全量）的唯一官方通道。

而 Google 对这套机制的自我评价是："A/B 系统之所以非常强大，是因为任何错误（如 I/O 错误）都只能影响未使用的分区集，并且可以进行重试"[1]。

——呵呵，非常强大？且看后文分解。😅

### 1.2 update_engine 的启动机制：从 Bootloader 到 Binder

update_engine 并非由应用框架层随意拉起。它的启动遵循一条严格的底层链条。根据 AOSP 源码中的 update_engine.rc 配置文件[2]：

```
service update_engine /system/bin/update_engine
    class main
    user root
    group root cache inet
    seclabel u:r:update_engine:s0
    disabled
    shutdown critical
    on property:ro.boot.slot_suffix=*
        setprop update_engine.slot_suffix ${ro.boot.slot_suffix}
        start update_engine
```

这个配置揭示了几个关键事实：
- disabled：该服务不会随 class main 自动启动，必须由特定事件触发。
- on property:ro.boot.slot_suffix=*：启动的唯一触发器是 ro.boot.slot_suffix 系统属性被设置，该属性来源于 Bootloader 通过内核命令行传递的当前激活槽位信息（如 androidboot.slot_suffix=_a）[3]。
- user root：update_engine 以 root 身份运行，拥有直接读写系统分区的最高权限。

整个启动流程可概括为：Bootloader → Kernel → Init（属性系统）→ 执行二进制 → 注册 Binder 服务。

这意味着什么？意味着 update_engine 从诞生之初就被设计为一个特权幽灵——它拥有连 root 用户都未必能轻易干涉的内核级资源占有能力，而它的启动完全取决于 Bootloader 传参和属性触发，用户态几乎无法干预其生命周期。😱

### 1.3 update_engine 的状态机：严谨还是脆弱？

update_engine 内部维护了一个严格的状态机。当 OTA 被触发后，其流转路径大致为：

```
Idle → CheckingForUpdate → UpdateAvailable → Downloading → Verifying → Finalizing → UpdatedNeedReboot → Idle
```

在 AOSP 官方文档中，这一流程被描述为几个典型阶段[1]：
- 正在更新：系统正在从当前槽位运行，目标槽位中的内容"正在更新，但是尚未完成"，因此该槽位"标记为不可启动"。
- 已应用更新，正在等待重新启动：目标槽位已被标记为可启动但尚未成功，引导加载程序应从其启动尝试。
- 系统重新启动到新的更新：首次从新槽位运行，旧槽位仍为可启动且成功状态。

关键阶段详解：
- Downloading：写入 payload 到目标插槽，期间会创建 device-mapper 快照（COW 设备），对目标分区进行写时复制保护。官方文档在描述 Virtual A/B 实现时，明确定义了快照的合并状态包括 NONE、UNKNOWN、SNAPSHOTTED、MERGING、CANCELLED[4]。
- Finalizing：执行 postinstall 脚本（若有），并开始快照合并。官方文档描述："对于其中已定义安装后步骤的每个分区，update_engine 会将新分区装载到特定位置，并执行与装载的分区对应的 OTA 中指定的程序"[1]。在此阶段，快照状态为 MERGING，合并操作将 COW 设备中的差异数据合并回原始物理分区[4]。
- UpdatedNeedReboot：写入与合并完成，设置新插槽为可启动，标记"需要重启以完成更新"。官方流程描述为："系统重新启动到新的更新：系统首次从插槽 A 运行"[1]。
- 重启进入新系统后：update_engine 会在后台调用 markBootSuccessful()，将新槽位的"成功"属性设置为 true。官方文档明确指出："被标记为成功的槽位应该能够自行启动、运行和更新"[1]。然后进入 Idle 状态，释放旧槽的所有资源。

这一切听起来环环相扣，但魔鬼就藏在细节里。官方文档自始至终没有提到：如果守护进程在 Finalizing 或 UpdatedNeedReboot 阶段异常退出，会发生什么？ 没有任何超时机制，没有任何自愈逻辑，没有任何回退保护。Google 似乎默认 update_engine 永远不会出错。🤔

### 1.4 独占文件描述符：内核的铁律 ⚖️

在 Linux 内核中，当 update_engine 为了执行 COW 或直接写入而打开一个块设备（比如 /dev/block/by-name/system_b）时，它会使用 O_EXCL 标志或等效的排他打开模式。这不是什么安全功能，而是为了防止多个进程同时写入块设备导致数据交错损坏的基本保护。

一旦某个进程（即使它已经死了，但文件描述符未被关闭）以独占方式打开了块设备，内核的块设备层会直接拒绝任何后续的写入 open() 调用，并返回 -EBUSY。这个拒绝发生在 VFS 层，优先于一切权限检查。Root 可以无视 UID/GID，甚至可以关闭 SELinux，但无法解除另一个内核对象对资源的占有。这就是为什么我们的故事如此吊诡。😡

update_engine 的 disabled 属性和 shutdown critical 标志，本意是确保更新过程不被打断。但当更新被打断后，这些保护机制反而成了制造幽灵的温床——它们确保了 update_engine 在持有资源时不会优雅退出，但没有任何机制确保它在被意外杀死后能释放那些资源。

随手翻看上文 delta_performer.cc 中的 OpenPartition() 函数，你会发现它调用 fd-&gt;Open(partition_path.c_str(), O_RDWR, 0) 时，参数列表里连个 O_CLOEXEC 的影子都没有。而 snapshot_merge_performer.cc 的 Cleanup() 方法依赖着 Merge() 正常返回才能被调用——只要 Merge() 里任何地方抛异常或进程被杀，清理代码就是一行死字。

它选择把一切希望寄托在"更新流程必将完美运行到底"的幻想上，留下一个到处都是资源泄漏的烂摊子。而官方文档中对快照合并状态 CANCELLED 的定义[4]，暗示 Google 的设计者至少考虑过"取消"的场景——但他们偏偏没有考虑"进程被意外杀死后谁来执行取消"这个现实问题。这种设计放在任何一家正经公司，代码审查都别想通过，但它偏偏就躺在 AOSP 的主线分支里，年复一年地坑着每个刷机人。😤

## 第二章：案发现场——一次完美的 OTA，一个永锁的分区 🕵️

### 2.1 复现步骤与关键故障节点

为了让读者能够亲手触发这一故障，或在自己的设备上验证是否存在类似隐患，现将完整的复现过程记录如下。每一步都标注了可能出现问题的技术节点，方便定位和调试。

设备状态：OnePlus 设备，搭载类原生 ColorOS，当前工作插槽为 A，系统正常运行。设备已刷机，已解锁 Bootloader，已获取 root 权限，AVB 2.0（dm-verity）处于禁用状态。 这是所有已确认案例的共同前提——未刷机、未解锁的普通用户暂未报告遭遇此问题。

通过以上步骤，可以 100% 复现该幽灵锁死现象。核心问题节点在步骤 2 向步骤 3 过渡期间，即重启进入新系统后，update_engine 未能完成提交阶段，却悄无声息地保留了旧槽的设备占用。最阴险的是，整个过程中除了第一屏卡顿 40 秒这一预警信号外，系统没有任何可见错误，普通用户甚至不知道自己的旧插槽已经被永久绑架。

&gt; ⚠️ 复现风险警告：如果你在步骤 2 的重启过程中没有观察到第一屏卡死超过 40 秒的现象，请立刻停止尝试。这意味着你的设备上 update_engine 的提交阶段已经正常完成，旧槽没有被锁死。此时强行执行后续步骤中的 dd 写入或重置更新服务不会带来任何好处，反而可能引入不必要的风险。更重要的是，每一次无意义的复现尝试，都是在消耗你设备上 eMMC/UFS 存储颗粒的写入寿命。你的硬盘颗粒会在天上失禁地望着你，为它们被白白浪费的 P/E 周期哭泣。😭 如果你只是为了验证本文描述的现象，看一眼第一屏的启动时间就够了——超过 40 秒就是铁证，否则请收手。

&gt; 机型与系统限定声明：截至目前，所有已确认复现的幽灵锁死案例，均出现在 OnePlus 机型或搭载 ColorOS 系统的设备上。这并不意味着其他品牌（如 Pixel、小米、三星）的 A/B 设备绝对不会出现类似问题——理论上，任何使用 A/B 更新的 Android 设备都继承了相同的代码基础——但在实际收集到的样本中，仅上述机型有确凿案例记录。如果你使用的是其他品牌设备，本文的原理分析仍然有效，但触发条件可能因 OEM 对 update_engine 的定制程度不同而存在差异，切勿在没有证据的情况下轻率归因。

### 2.2 徒劳的挣扎 😫

在发现锁死后，我进行了数小时的常规排查，结果无一例外地失败：
- umount？该分区根本没有被挂载。
- blockdev --setrw？它已经是可读写的。
- disable-verity？dm-verity 根本没有在保护它。虽然官方文档提到 "dm-verity 可保证设备使用的启动映像未损坏"[1]，但这里出问题的不是 dm-verity。
- 检查 AVB 2.0 / dm-verity 状态：已禁用（因刷机需要）。这意味着 system、vendor 等分区的完整性验证已被关闭，块设备的写保护不来自验证启动链。这也排除了"AVB 阻止写入"的可能性，反证锁死的根源在更底层。
- 检查 SELinux？已处于 Permissive 模式。
- 重启设备？问题依旧。

分区看起来完全正常，没有任何错误标志，但就是拒绝任何写入。它像一个黑洞，平静而坚定地吞噬掉所有写入尝试，连一个字节都不允许。🤬

官方文档信誓旦旦地说："任何错误（如 I/O 错误）都只能影响未使用的分区集，并且可以进行重试"[1]。然而现在的情况是：没有任何错误报告，但旧分区集被永久锁定，且没有任何官方手段可以重试或重置。

### 2.3 怀疑的转折：从硬件锁到软件鬼魂 👻

我一度怀疑硬件写保护被意外触发（比如 eMMC CMD28）。但如果是硬件锁，为什么另一个新插槽完全正常？为什么重启不能解除（临时写保护掉电即失）？

直到我把目光投向了 dmesg 和 update_engine 的日志，一个荒谬的真相终于浮出水面。那个本该在 OTA 完成后安静退休的 update_engine，竟然像个孤魂野鬼一样，仍然死死攥着旧插槽 A 的分区设备文件。

通过检查 /proc/*/fd，我发现了指向 /dev/block/by-name/boot_a 和 system_a 的已失效文件描述符。它们属于一个已经被杀死的 update_engine 子进程（可能是 snapuserd 或合并线程），该进程在某个时间点被系统草率地终止了，却没有执行任何清理动作。

内核说："这个设备正被占用，滚开。"
而那个占用者早已是个死魂灵。Root 拿一个死魂灵毫无办法。😈

### 2.4 极端案例：相机等边缘化设备的集体叛变 📸

就在本案例的初期分享后，社区中陆续出现了更加匪夷所思的反馈：在同样已 root、AVB 已禁用的 OnePlus/ColorOS 设备上，有用户不仅遇到了旧槽锁死，还发现系统功能出现诡异残缺——相机无法启动、闪光灯失踪、甚至是蓝牙或 Wi-Fi 间歇性罢工。这些边缘化设备（通常不被视为系统核心组件）在 OTA 后竟然集体失效，而系统版本号和"关于手机"界面一切正常，没有任何错误弹窗。😱

经过溯源分析，这些诡异现象同样是 update_engine 状态卡死带来的连锁反应。要理解这一点，必须跳出"系统 = system 分区"的狭隘认知。现代 Android 设备的关键驱动和固件散布在多个物理分区中：
- vendor 分区：包含硬件抽象层（HAL）的二进制实现，相机 HAL 就是典型的例子。
- odm 分区：原始设计制造商（ODM）的自定义配置和专有库，某些传感器校准数据也放在这里。
- dtbo / vbmeta：设备树叠加层和验证元数据，与内核驱动加载直接相关。

A/B 更新同样会复制这些分区（vendor_a/vendor_b、odm_a/odm_b 等）。根据 Virtual A/B 官方文档[4]的描述：

&gt; "使用 Virtual A/B 时，目标槽位中的分区在更新完成之前不会直接写入。相反，对目标槽位的所有写入都会被重定向到一个名为 快照 的写时复制 (COW) 设备。"

以及：

&gt; "如果设备在合并完成之前断电，或者合并因故未能完成，设备在下次启动时必须能够回退到合并前的状态，或者从上次中断的地方继续合并。"

这两段话揭示了一个致命的事实：Google 明确承认合并可能因断电等原因未能完成，但将"如何继续合并或回退"的实现责任完全推给了 OEM，AOSP 本身并未提供强制超时或自动修复机制。😤

而在源码层面，update_engine 处理更新 payload 写入的核心逻辑 delta_performer.cc[7] 中，ApplyPayload() 函数会根据分区操作列表，对每一个需要更新的分区依次执行写入，覆盖范围远不止 system 分区：

```
// delta_performer.cc - ApplyPayload() 遍历所有分区并执行写入
for (const auto&amp; partition_update : manifest.partitions()) {
    // 此处依次处理 boot、system、vendor、product、odm 等所有 A/B 分区
    if (!OpenPartition(partition_update, target_slot_suffix, &amp;fd)) {
        return false;
    }
    // 执行实际数据写入 ...
}
```

A/B 系统更新总览文档[1] 同样列出了 A/B 更新实际覆盖的完整分区清单，与源码中的操作列表完全一致。

一旦状态卡死在 Finalizing 或 UpdatedNeedReboot，snapshot_merge_performer.cc[8] 中的 Merge() 函数将永远等不到它的高光时刻——它要么在启动阶段被系统草率地跳过（因为第一屏卡顿超时后 init 进程强制继续），要么在执行中途被杀死，而 Cleanup() 作为它的"遗嘱执行人"，根本就没有被通知到场。此时系统实际运行在两个"世界"的夹缝中：
- 内核和 Android 框架已经从新插槽 B 启动，期待使用新版本的 HAL 库和固件。
- 但由于合并未完成，vendor_b 或 odm_b 中可能还残留着未合并的旧数据，或者快照设备映射并未完全拆除，导致某些库文件实际上是损坏的或不完整的。
- 对于相机这类边缘设备，其 HAL 服务启动时发现固件版本不匹配或者关键 .so 文件无法正常加载，便会静默失败，表现为相机应用黑屏、闪光灯开关消失、或人脸识别不可用。

更讽刺的是，Google 官方文档描述 Virtual A/B 时轻描淡写的一句："快照合并状态包括 MERGING、CANCELLED……"[4]，却完全没有警告开发者：如果合并意外中断，设备将进入一个"框架新、驱动旧"的割裂状态，部分外设可能永久残废，直到手动修复。 🤬

而修复方法也异常粗暴但有效——既然问题根源于分区状态不一致，唯一的解药就是让所有分区重新同步到当前运行的版本：
- 先强制重置更新服务状态（rm -rf /data/misc/update_engine/* &amp;&amp; killall update_engine），释放旧槽锁死，并使状态机回归 Idle。
- 下载当前已启动系统对应的官方全量包（注意必须是当前版本，不能是旧版），通过本地 OTA 或手动 fastboot 方式将其重新刷入当前运行的插槽。
- 这次刷写会强制覆盖所有相关分区（包括 vendor、odm、dtbo 等），消除任何残留的 COW 快照或版本不匹配，让硬件驱动恢复到该版本应有的完整状态。

这一方法已被多名用户（同样是已 root、已解锁的 OnePlus/ColorOS 设备用户）证实能够完美复活相机等设备。😋

&gt; 再次重申：这些极端案例同样全部出现在已 root、AVB 已禁用的 OnePlus/ColorOS 设备上。未刷机设备用户理论上也可能遭遇快照合并失败，但由于其系统分区受到 dm-verity 的严格保护，分区级不一致通常会直接导致系统拒绝启动（回退到旧槽），而非"能启动但部分设备失效"的半残状态。恰恰是 root 和 AVB 禁用，让 Google 代码中的隐患得以用更隐蔽的方式暴露出来。 其他品牌设备目前未收集到类似极端案例报告，本文不做过度推断。

## 第三章：Google 的七宗罪——为什么这个 bug 如此荒谬 😡

至此，真相大白：在已 root、AVB 已禁用的 ColorOS 设备上，update_engine 在 OTA 的"提交阶段"异常退出，遗留下未释放的独占文件描述符，导致旧插槽被内核永锁。 但如果我们深究下去，就会发现这不是一个简单的偶发异常，而是 Google 设计失当的集中体现。以下每一条指控，都有官方文档和源码为证。

### 第一宗罪：状态机没有超时与自愈能力 💀

update_engine 的状态机就像一列单轨火车：任何中间站抛锚，整条线路永久停摆。官方文档详尽描述了从 Idle 到 UpdatedNeedReboot 的每个状态[1]，但全篇找不到一个字提到超时处理或异常恢复。如果你在 Finalizing 或 UpdatedNeedReboot 阶段挂掉，状态文件会忠实记录"还没完成"，但却没有任何 watchdog 去校验系统实际已经成功运行在新插槽上。

一个 if (system_is_running_fine) then release_old_slot() 的逻辑就这么难写吗？Google 在设计 update_engine 的状态机时，显然假设世界是完美的——进程永远不会被杀，电池永远不会耗尽，用户永远不会在错误的时间点强制关机。这种程序设计哲学，配得上"幼稚"二字。🤡

### 第二宗罪：资源清理失败是幼儿园级的错误 🍼

无论进程是如何死亡的（kill -9、系统杀、自己崩溃），占用资源都必须释放。这是操作系统设计的基本准则，任何一个修过 CS101 的学生都懂。update_engine 完全可以使用 O_CLOEXEC 标志或注册 atexit 钩子来确保文件描述符被关闭，但它没有。

随手翻看上文 delta_performer.cc 中的 OpenPartition() 函数，你会发现它调用 fd-&gt;Open(partition_path.c_str(), O_RDWR, 0) 时，参数列表里连个 O_CLOEXEC 的影子都没有。而 snapshot_merge_performer.cc 的 Cleanup() 方法依赖着 Merge() 正常返回才能被调用——只要 Merge() 里任何地方抛异常或进程被杀，清理代码就是一行死字。

它选择把一切希望寄托在"更新流程必将完美运行到底"的幻想上，留下一个到处都是资源泄漏的烂摊子。而官方文档中对快照合并状态 CANCELLED 的定义[4]，暗示 Google 的设计者至少考虑过"取消"的场景——但他们偏偏没有考虑"进程被意外杀死后谁来执行取消"这个现实问题。这种设计放在任何一家正经公司，代码审查都别想通过，但它偏偏就躺在 AOSP 的主线分支里，年复一年地坑着每个刷机人。😤

### 第三宗罪：对"更新完成"的定义反人类 🤔

一个系统是否完成更新，最权威的证据应该是系统本身是否正常运行，而不是 /data/misc/update_engine/ 下的一个 XML 文件。

官方文档定义："被标记为成功的槽位应该能够自行启动、运行和更新"[1]。好，我的设备已经在新槽位上成功启动、正常运行、功能无异常——按照 Google 自己给出的标准，这就是一个"成功"的槽位。然而 update_engine 的内部状态机不管这些现实证据，它只认那个持久化状态文件。只要那个文件说"还没完成"，管你系统跑得多欢，旧插槽就永远是"正在更新的禁区"。

Google 把持久化状态当成了唯一的真理之源，却完全忽视了现实世界已经发生的客观事实。这种用不可靠的元数据否决物理现实的做法，堪比刻舟求剑。🤣

### 第四宗罪：独占锁的使用漫不经心 🔒

O_EXCL 是用于防止并发写入的重要机制，但必须与严格的资源生命周期管理配合。Google 的代码显然没有做到这一点。

官方文档反复强调 A/B 机制的设计初衷是"将未使用的槽位保留为后备槽位，从而使更新具有抗故障性"[1]。这个初衷是好的——把未使用的槽位保护起来，防止意外损坏。但问题在于：更新已经结束，系统已经在另一槽位成功运行，旧槽的资源保护已经不再需要。此时继续持有独占文件描述符，不是保护，是绑架。这就像一个锁匠开完锁后把钥匙吞进了肚子里，然后转身走了，留下门永远打不开。😡

### 第五宗罪：上梁不正下梁歪——OEM 们的变本加厉 🏠

这个缺陷根植于 AOSP 的 update_engine 实现，意味着所有 A/B 设备理论上都遗传了这个定时炸弹。官方文档中明确提到："实现 A/B 系统更新的原始设备制造商 (OEM) 和 SoC 供应商必须确保其引导加载程序实现 boot_control HAL，并将正确的参数传递到内核"[3]。

Google 把实现细节甩给 OEM，自己在 AOSP 里留下一个有资源泄漏隐患的参考实现。更糟糕的是，OEM 们还在其上叠加了自己的"安全策略"：小米的 ARB、三星的 SW_REV 熔断……它们都是在同一个脆弱基础上增加更多不可逆的锁。Google 教出的好儿子们，正在把用户推向更深的深渊。😈

### 第六宗罪：root 权限的边界被悄然颠覆 🔑

Google 给 update_engine 赋予了 user root 的最高权限[2]，让它"负责在后台安全地下载、验证并应用系统更新"[1]。但 Google 从未在任何公开文档中告知用户：这个以 root 身份运行的服务，可以在你不知情的情况下，占用并锁死你的硬件资源，而你连 root 都无法解除它的锁。

这是一种权限的黑洞——update_engine 使用 root 权限打开了块设备，然后内核授予它独占权。当它异常死亡后，这个独占权变成了一个无主的锁，而另一个 root 用户（你）无法强行夺走它，因为内核不允许两个写入者同时存在。这是一个完美的死锁：需要 root 权限去创建它，但不需要任何权限去永久持有它。 😨

### 第七宗罪：对用户的可恢复性零考虑 🚫

官方文档自豪地宣称 A/B 更新机制可以"降低更新之后设备无法启动的可能性，这意味着用户需要将设备送到维修和保修中心进行更换和刷机的情况将会减少"[1]。

但我的设备并没有"无法启动"——它启动得很好。它只是被悄悄地锁住了一个硬件资源，而且没有任何官方工具可以解除这个锁。普通用户甚至不知道自己的旧插槽已经被绑架了。高级用户发现了，也只能通过非官方的、需要 root 的暴力手段（重置更新服务）来解决。如果我没有 root 呢？如果我不懂 update_engine 的内部机制呢？答案只有两个字：忍着。😡

## 第四章：破解与自动化——我如何替 Google 擦屁股 🧹

### 4.1 最简单的修复：重置更新服务

既然幽灵是因为状态文件不释放而阴魂不散，那么强制清除它的存在即可：

```
# 强制停止 update_engine 并清空其持久化状态
rm -rf /data/misc/update_engine/*
killall update_engine
```

瞬间，所有被持有的文件描述符被内核回收，dd 恢复工作。旧槽重获自由。😋

有趣的是，AOSP 源码中其实存在一个重置相关的能力——在 update_attempter_android.cc[9] 中，确实存在一个 ResetStatus() 方法，它可以清除更新状态并将状态机重置为 Idle。但 Google 只把它用在内部测试或某些极端异常处理中，从未通过 update_engine_client 或任何公开 API 暴露给用户。也就是说，Google 的工程师们自己可以用它来救砖，但用户只能望洋兴叹。这就是 Google 对"可恢复性"的真实态度：我能做，但我不给你用。🤬

针对极端案例（相机等外设失效）的附加步骤：在重置更新服务后，务必下载当前系统版本的官方全量包，重新刷入当前运行的插槽一次。这一步会强制覆盖所有 vendor、odm 等分区，彻底消除因快照合并中断导致的驱动不匹配，让所有边缘化设备恢复正常。

### 4.2 KernelSU 模块：自动化解锁幽灵锁 🛡️

手动敲命令不够优雅，我写了一个 KernelSU 模块，在每次开机时自动检测：
- 检测到本次启动插槽与上次记录不同（发生了 OTA 切换）
- 向未使用的旧插槽尝试写入 0 字节探测（打开 O_WRONLY 立即关闭）
- 如果打开失败（EBUSY），判定为幽灵锁死，立即重置 update_engine 服务

这个模块轻量、无侵入，只在必要时执行，完美解决了 Google 留下的烂摊子。从此我的设备再也无需手动救砖。😎

&gt; 模块开源地址：[GitHub 链接]（欢迎 Star 和贡献）

## 第五章：一份公开的判决书 ⚖️

被告：Google LLC

罪名：资源管理失当、状态机设计不健壮、将技术债转嫁给用户和 OEM、教子无方导致生态崩坏

证据清单：
- [1] A/B（无缝）系统更新官方总览文档，详述 update_engine 架构、状态流转及设计目标，但全篇未包含异常恢复逻辑；明确列出 A/B 分区涵盖 vendor、odm 等与硬件驱动直接相关的分区。
- [2] AOSP 源码 update_engine.rc 配置文件，证明该服务以 root 身份运行、被标记为 disabled 和 shutdown critical，缺乏进程异常退出后的资源自动释放保障。
  源码铁证：
  - delta_performer.cc[7] 中 OpenPartition() 函数在打开分区文件描述符时未使用 O_CLOEXEC，导致进程异常退出时 fd 无法被内核自动回收；
  - snapshot_merge_performer.cc[8] 中 Cleanup() 方法只能在 Merge() 正常返回后执行，异常路径下快照设备映射和块设备占用不会被清理；
  - update_attempter_android.cc[9] 中存在 ResetStatus() 方法可重置状态机，但该方法未通过任何公开 API 暴露给用户；
  - utils.cc[10] 中底层 OpenFile() 封装未对块设备统一添加 O_CLOEXEC。
  以上源码片段（已于前文完整展现）共同构成"资源泄漏与不可恢复"的完整证据链。
- [4] Virtual A/B 概览官方文档，定义快照合并状态（NONE、UNKNOWN、SNAPSHOTTED、MERGING、CANCELLED），明确承认"合并可能因断电等原因未能完成"，但未规定进程崩溃后的自动清理机制；COW 快照机制描述直接解释了旧槽分区被独占占用的技术根源。
- 本人设备复现案例（完整步骤见第二章，所有复现均在已 root、AVB 2.0 已禁用的 OnePlus/ColorOS 设备上完成）：dd 返回 Device or resource busy，证实内核级独占锁生效且无法由 root 解除；本地 OTA 安装失败证实状态机拒绝新请求；重置更新服务后一切恢复正常。
- 社区反馈的极端案例（同样限定于已 root、AVB 已禁用的 OnePlus/ColorOS 设备）：多名用户报告 OTA 后相机、闪光灯等外设集体失效，症状符合 vendor/odm 分区 COW 快照合并中断导致 HAL 库不完整的特征；重置更新服务并重刷当前版本官包后所有设备恢复正常，证实问题根源于分区级驱动不匹配。源码 delta_performer.cc[7] 中遍历所有分区的写入逻辑（已在前文展现）和 snapshot_merge_performer.cc[8] 中 Cleanup() 的不可达路径，为极端案例提供了直接的技术解释。
- 所有采用 A/B 无缝更新的 Android 设备均潜在继承此缺陷的代码基础，但截至目前，实际已确认触发案例仅限 OnePlus/ColorOS 平台。其他品牌设备可能存在相同隐患，但缺乏实证。

判决：永久公开处刑，以儆效尤，并责令相关责任方立即采取行动：

Google 方面，必须在 AOSP 中实施以下修复：
- 在 update_engine 启动时，若检测到系统已从新插槽成功运行（boot_successful = true），则无条件释放旧插槽的所有独占文件描述符和 device-mapper 映射。
- 为所有块设备打开操作使用 O_CLOEXEC 标志，确保进程异常退出时文件描述符被内核自动回收。具体修改文件：delta_performer.cc、utils.cc。
- 在 snapshot_merge_performer.cc 中引入超时与异常保护机制：若 Merge() 执行超过预定时间或进程收到终止信号，必须强制执行 Cleanup() 释放资源。
- 将 update_attempter_android.cc 中的 ResetStatus() 方法通过 update_engine_client 命令公开暴露（如 update_engine_client --reset），允许用户手动强制重置更新服务状态。
- 在官方文档中增加一节"异常恢复"，诚实告知开发者和用户 A/B 更新可能出现的资源锁死问题及其解决方案，包括因合并失败导致的硬件功能异常的修复步骤。

各大 OEM 厂商方面（目前案例集中在 ColorOS，但原理适用于所有 A/B 设备），我们同样发出呼吁 📢：
- 不要仅满足于 UI 的美观和系统的流畅度。一个真正优秀的系统，应该在用户遇到故障时，提供清晰、可排查的诊断路径，而不是让用户在黑盒中恐慌性摸索。 当 update_engine 状态异常时，系统设置中的"软件更新"页面应当显示明确的状态提示（而非沉默的"安装失败"弹窗），并提供"重置更新状态"的官方选项，让用户即使在没有 root 的情况下也能自救。
- 对于因快照合并失败导致的边缘设备异常，系统应在开机自检阶段主动检测分区一致性，并在发现问题时通过通知栏或设置页面提示用户执行修复，而不是让用户面对"相机打不开"的诡异现象一头雾水，最终误判为硬件故障而浪费售后资源。
- 请在厂商的官方社区和售后知识库中，加入对此类问题的排查指南。让刷机玩家在遇到问题时能够有据可查，而不是在论坛和群聊中靠口口相传的民间偏方自救——这不仅是对用户的尊重，也是对售后成本的实际节约。

前瞻性建议：为更新流程注入透明度与可观测性 🔭

除了修复现有缺陷，我们也郑重建议 Google 在 update_engine 的关键状态流转节点（如进入 Finalizing、开始 Merge、Cleanup 完成等）添加明确的检查点记录。这些记录应持久化到稳定的存储区域，并在系统属性或诊断界面中向用户可见。即使官方出于谨慎不提供自动修复，至少让用户能够查看到类似这样的信息：

```
Update state: Finalizing
Snapshot merge: in progress (vendor_b: 67%, odm_b: 52%)
Last checkpoint: Merge started at boot time + 12s
```

即便系统最终无法自行恢复，至少用户能知道问题卡在哪个环节、是哪块分区的合并没完成。官方可以不帮我们擦屁股，但请给我们一张地图，让我们自己找到茅坑在哪 🤡——死不可怕，死得不明不白才可怕。这不仅是对刷机玩家的尊重，更是对整个 Android 生态系统可维护性的长远投资。

同时，我们理解刷机本非"正常人"干的事，但代码的健壮性不应以用户是否越界来衡量。一套设计良好的系统，即使面对越权操作或异常中断，也应当保持内部状态的一致性或至少做到"优雅的失败"。与其亡羊补牢地封锁 root，不如在代码逻辑中为意外情况留下生存空间——这才是真正值得细细考量和测试的地方。🧪

## 终章：给刷机人的忠告 💬

Root 给了我们钥匙，但 Google 的代码给了我们监狱。😞

我们理解，刷机意味着放弃保修，意味着走上一条不被官方支持的道路。但这不应该是厂商把系统内部状态变成黑盒的理由。我们需要的，不仅是一个流畅好用的系统，更是一个在出现故障时能够心安理得地排查问题的系统——而不是对着一个 Device or resource busy 的报错，或者一个无故罢工的相机，在搜索引擎里疯狂输入关键词，最后靠某个民间大神的帖子才找到一条藏在 /data/misc/ 深处的救命命令。良好的故障透明度与可恢复性，和精美的动画、顺滑的帧率一样，都是一个成熟操作系统的基本素养。我们呼吁 Google 和所有 OEM 厂商，在追求体验升级的同时，也请给故障排查留一扇门。🚪

必须承认，我们手上的这把"钥匙"——root 权限和 AVB 禁用——本身就让系统处于非常规状态。Google 完全有权辩称："你刷机了，你活该。" 但这并不能掩盖一个事实：一个以 root 身份运行的、被标记为 shutdown critical 的系统服务，在遇到异常时没有能力清理自己留下的资源。 你关闭了门禁，但清洁工把拖把卡在了消防通道里，然后下班了——这是两码事。门禁的缺失让问题更容易被发现，但拖把卡住的责任，永远在清洁工。😤

在 Android 的底层，内核的铁律永远高于用户态的权限。update_engine 作为一个被 Google 赋予了 user root 权限和 shutdown critical 标志的特权守护进程，它在正常工作时是你可靠的更新管道工，但一旦异常死亡，它就变成了一个你无法触及的幽灵——它的尸体仍然攥着你的硬件，而内核这个死心眼的看门大爷，恪守着"一个设备不能有两个写入者"的规定，将你的一切写入尝试拒之门外。

Android 开源项目官方文档洋洋洒洒数千字，描述了 A/B 无缝更新的种种好处：降低变砖风险、减少售后维修、支持流式传输……唯独没有一句话提到：如果更新引擎自己变成了砖头怎么办？ 🤷

当你再次遇到连 root 都撞不开的墙，别急着怀疑硬件，去检查一下那些本该死去的守护进程，它们可能正攥着你的设备，在代码的阴间对你狞笑。👻

谨以此文，献给所有被 update_engine 坑过的搞机人。
我们生来自由，不愿被任何一个幽灵锁住插槽。 ✊

## 免责声明（必读）⚠️

没遇到这个情况的，当乐子看看得了。 特别是如果你从未刷机、Bootloader 锁得好好的、系统原装无修改——那么恭喜你，这篇文章对你来说就是个故事。因为目前所有的幽灵锁死案例，都只发生在已经 root 的 OnePlus/ColorOS 设备上。😄

如果你不幸遇到了——请先确认你的设备状态：你是否刷过机？是否解锁了 Bootloader？是否获得了 root 权限？AVB 2.0 是否被禁用？如果是，且你的设备正好是 OnePlus 或搭载 ColorOS 的机型，那么你大概率中了本文描述的幽灵锁死。 请先深呼吸，不要砸手机，不要恢复出厂设置，不要听售后忽悠换主板。你手上拿着的不是砖头，是一个被 Google 的烂代码暂时绑架的人质。按照本文第四章的步骤操作，它大概率能完好如初地回到你手中。😌

如果你的设备从未刷机、Bootloader 锁定、一切原装——那么你遇到此问题的概率极低。因为 dm-verity 会在分区不一致时直接拒绝启动，系统会回退到旧槽，你不会看到"系统正常但旧槽锁死"的诡异状态。你的故障大概率是其他原因，请寻求官方售后支持。📞

如果你使用的是其他品牌的 A/B 设备（Pixel、小米、三星等）且遇到了类似症状——请谨慎参考本文，但不要轻率归因。目前我们没有收集到这些品牌的确凿案例。如果你真的发现了，欢迎带着详细日志到本文的 GitHub 仓库提 Issue，一起把这场"公开处刑"的被告名单扩展得更长。😉

再次郑重重申：本文所剖析的一切现象，均为在已解锁、已 root 并禁用 AVB 验证的设备上进行非常规操作（如手动刷写、修改系统分区）后的衍生产物。Google 完全有权说："你放弃了保修，我们不负责。" 然而，我们仍然呼吁 Google 重视并修复这一潜在隐患。因为即使在没有 root 的普通设备上，类似的更新状态卡死也可能在极端情况（如意外掉电）下发生。而对于刷机新手来说，一旦遇到"设备正常但分区神秘锁死"或"相机无端失效"这类症状，极易被误导为硬件故障，引发不必要的恐慌和昂贵的售后纠纷。一个更健壮的 update_engine，不仅是对刷机玩家的尊重，更是对所有 Android 用户的基本保障。🤝

致各大厂商（特别是 ColorOS 团队）：我们感谢你们在系统优化和用户体验上的持续投入。但我们也希望你们能够理解：一个真正优秀的 ROM，不应该只在一切正常时光鲜亮丽，而应该在出现问题时也能让用户心中有数、手中有策。请考虑在系统更新模块中增加更透明的状态提示和更友好的重置机制。这不仅能让刷机玩家少走弯路，也能减少因系统状态异常导致的售后纠纷和保修成本。毕竟，一个能让用户在出问题时自己排查清楚的系统，才是真正值得信赖的系统。❤️

刷机或许不是"正常人"干的事，但代码的健壮性值得细细考量和测试 🧪——哪怕一行简单的 O_CLOEXEC，或者一个检查点日志，都可能在未来拯救成千上万块被误认为"变砖"的设备。我们呼吁 Google 和 OEM 厂商在开发过程中，不仅考虑理想的成功路径，也为意外中断留下合理的退路。

如果你在梦中穿越到硅谷，想就此事与 Google 开发团队进行一番"友好交流"，请前往以下地址：
&gt; Googleplex 总部
&gt; 1600 Amphitheatre Parkway
&gt; Mountain View, CA 94043
&gt; United States

到达后请径直走向 Building 43（Android 雕像草坪所在地），对着那群给 update_engine 写状态机的人，替我问一句：

"你们自己写过 watchdog 吗？学过 O_CLOEXEC 吗？知道什么叫资源生命周期管理吗？" 😡

如果他们一脸茫然，请把本文的打印稿拍在他们桌上，然后优雅地转身离开。📄

如果他们反问"你怎么找到这里的"——告诉他们：比你们代码更靠谱的，是 GPS。 😋

&gt; 作者：周航航（DevCloud.ZTR_OS）
&gt; 完整案例复现、模块源码及更多技术细节，尽在 GitHub 仓库：https://github.com/ABI-ZTROS/AB-Unlocker
&gt; 如果这篇文章帮你拯救过设备，或者让你笑出了声，请给个 Star——那是给 Google 工程师最好的耳光。 😋

## 引用源链接

- A/B（无缝）系统更新 - Android 开源项目官方文档
  https://source.android.google.cn/docs/core/ota/ab
  （英文版：https://source.android.com/docs/core/ota/ab）
- update_engine.rc 源码 - AOSP system/update_engine/init/
  https://android.googlesource.com/platform/system/update_engine/+/refs/heads/main/init/update_engine.rc
- boot_control HAL - Android 开源项目官方文档
  https://source.android.google.cn/docs/core/ota/boot_control
  （英文版：https://source.android.com/docs/core/ota/boot_control）
- Virtual A/B 概览 - Android 开源项目官方文档
  https://source.android.google.cn/docs/core/ota/virtual_ab
  （英文版：https://source.android.com/docs/core/ota/virtual_ab）
- AOSP update_engine 源码仓库
  https://android.googlesource.com/platform/system/update_engine/
- OTA 工具与 build 系统集成 - Android 开源项目
  https://source.android.google.cn/docs/core/ota/tools
  （英文版：https://source.android.com/docs/core/ota/tools）
- delta_performer.cc 源码 - AOSP system/update_engine/payload_consumer/delta_performer.cc
  https://android.googlesource.com/platform/system/update_engine/+/refs/heads/main/payload_consumer/delta_performer.cc
  关键函数：OpenPartition() 未使用 O_CLOEXEC，ApplyPayload() 遍历所有分区执行写入。
- snapshot_merge_performer.cc 源码 - AOSP system/update_engine/payload_consumer/snapshot_merge_performer.cc
  https://android.googlesource.com/platform/system/update_engine/+/refs/heads/main/payload_consumer/snapshot_merge_performer.cc
  关键函数：Merge() 异常退出时 Cleanup() 不可达。
- update_attempter_android.cc 源码 - AOSP system/update_engine/update_attempter_android.cc
  https://android.googlesource.com/platform/system/update_engine/+/refs/heads/main/update_attempter_android.cc
  关键函数：ResetStatus() 存在但未公开暴露。
- utils.cc 源码 - AOSP system/update_engine/common/utils.cc
  https://android.googlesource.com/platform/system/update_engine/+/refs/heads/main/common/utils.cc
  关键函数：OpenFile() 底层打开未统一添加 O_CLOEXEC。
